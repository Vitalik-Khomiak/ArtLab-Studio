const copy = {
    uk: {
        "brand.role": "CG Generalist",
        "nav.work": "Роботи",
        "nav.about": "Профіль",
        "nav.contact": "Контакт",
        "hero.kicker": "Portfolio / 3D work",
        "hero.lead": "CG generalist зі Львова. Предметні рендери, середовища, hard surface, симуляції та айдентика в одному сфокусованому портфоліо.",
        "hero.viewWork": "Дивитись роботи",
        "hero.contact": "Написати",
        "fact.role": "Роль",
        "fact.focus": "Фокус",
        "projects.kicker": "Selected work",
        "projects.title": "Роботи",
        "projects.copy": "Product shots, cinematic frames, archviz, character sketches and simulation experiments.",
        "about.kicker": "Profile",
        "about.title": "CG generalist з фокусом на сильний кадр",
        "about.copy": "Я працюю з 3D-візуалізацією, предметним рендером, атмосферними сценами, hard surface моделінгом і експериментами з симуляціями. Мені важливо, щоб робота читалася швидко: форма, світло, матеріал і настрій мають одразу тримати кадр.",
        "contact.kicker": "Contact",
        "contact.title": "Є проєкт або питання?",
        "contact.copy": "Напиши коротко, що потрібно зробити. Повідомлення прийде на email.",
        "contact.email": "Твоя пошта",
        "contact.message": "Повідомлення",
        "contact.submit": "Надіслати",
        "footer.rights": "© 2026 ArtLab Studio. Всі права захищені.",
        "projectCount": "робіт у добірці",
        "openProject": "Відкрити роботу",
        "gridView": "Сітка",
        "listView": "Список"
    },
    en: {
        "brand.role": "CG Generalist",
        "nav.work": "Work",
        "nav.about": "Profile",
        "nav.contact": "Contact",
        "hero.kicker": "Portfolio / 3D work",
        "hero.lead": "CG generalist from Lviv. Product renders, environments, hard surface, simulations and visual identity in one focused portfolio.",
        "hero.viewWork": "View work",
        "hero.contact": "Contact",
        "fact.role": "Role",
        "fact.focus": "Focus",
        "projects.kicker": "Selected work",
        "projects.title": "Work",
        "projects.copy": "Product shots, cinematic frames, archviz, character sketches and simulation experiments.",
        "about.kicker": "Profile",
        "about.title": "CG generalist focused on a strong frame",
        "about.copy": "I work with 3D visualization, product rendering, atmospheric scenes, hard surface modeling and simulation experiments. The frame has to read fast: form, light, material and mood should hold attention immediately.",
        "contact.kicker": "Contact",
        "contact.title": "Have a project or question?",
        "contact.copy": "Write a short brief and it will arrive by email.",
        "contact.email": "Your email",
        "contact.message": "Message",
        "contact.submit": "Send",
        "footer.rights": "© 2026 ArtLab Studio. All rights reserved.",
        "projectCount": "works in view",
        "openProject": "Open project",
        "gridView": "Grid",
        "listView": "List"
    }
};

const categoryLabels = {
    branding: { uk: "Branding", en: "Branding" },
    product: { uk: "Product viz", en: "Product viz" },
    environment: { uk: "Environment", en: "Environment" },
    simulation: { uk: "Simulation", en: "Simulation" },
    character: { uk: "Character", en: "Character" },
    archviz: { uk: "Archviz", en: "Archviz" },
    abstract: { uk: "Abstract", en: "Abstract" }
};

const filters = [
    { id: "all", label: { uk: "Усі", en: "All" } },
    { id: "product", label: { uk: "Product", en: "Product" } },
    { id: "environment", label: { uk: "Environment", en: "Environment" } },
    { id: "simulation", label: { uk: "Simulation", en: "Simulation" } },
    { id: "character", label: { uk: "Character", en: "Character" } },
    { id: "archviz", label: { uk: "Archviz", en: "Archviz" } },
    { id: "branding", label: { uk: "Branding", en: "Branding" } },
    { id: "abstract", label: { uk: "Abstract", en: "Abstract" } }
];

const projects = [
    {
        id: "iem-katowice-2025",
        title: "IEM Katowice 2025",
        year: "2025",
        category: "branding",
        cover: "images/projects/iem_katowice_2025.png",
        ratio: "wide",
        role: { uk: "Візуальний дизайн", en: "Visual design" },
        focus: { uk: "Branding, lighting", en: "Branding, lighting" },
        description: {
            uk: "Промо-візуал для esports події: cyber doors, контрольований glow, глибина сцени та чистий рекламний фрейм.",
            en: "Promotional visual for an esports event: cyber doors, controlled glow, scene depth and a clean campaign frame."
        },
        tags: ["Event", "Lighting", "Branding"],
        gallery: ["images/projects/iem_katowice_2025.png"]
    },
    {
        id: "xbox-dualsense",
        title: "Xbox / DualSense",
        year: "2024",
        category: "product",
        cover: "images/projects/xbox_dualsense.jpg",
        ratio: "wide",
        role: { uk: "Product render", en: "Product render" },
        focus: { uk: "Hard surface, materials", en: "Hard surface, materials" },
        description: {
            uk: "Порівняльний кадр контролерів з акцентом на силует, пластик, дрібні деталі та студійне освітлення.",
            en: "Controller comparison frame focused on silhouette, plastic materials, small details and studio lighting."
        },
        tags: ["Product", "Hard surface", "Studio"],
        gallery: ["images/projects/xbox_dualsense.jpg"]
    },
    {
        id: "more-popcorns",
        title: "More Popcorns",
        year: "2024",
        category: "simulation",
        cover: "images/projects/more_popcorns.png",
        ratio: "square",
        role: { uk: "3D illustration", en: "3D illustration" },
        focus: { uk: "Food, dynamics", en: "Food, dynamics" },
        description: {
            uk: "Грайлива food-ілюстрація з відчуттям руху, випадковості та тактильності дрібних об'єктів.",
            en: "Playful food illustration with a sense of movement, randomness and tactile small-object detail."
        },
        tags: ["Food", "Simulation", "Lookdev"],
        gallery: ["images/projects/more_popcorns.png"]
    },
    {
        id: "varmilo-keyboard",
        title: "Varmilo Chang-e",
        year: "2024",
        category: "product",
        cover: "images/projects/varmilo_keyboard.jpg",
        ratio: "square",
        role: { uk: "Product visualization", en: "Product visualization" },
        focus: { uk: "Keycaps, color, light", en: "Keycaps, color, light" },
        description: {
            uk: "Візуалізація mechanical keyboard з акцентом на прозорість кейкапів, м'яке світло і декоративну подачу.",
            en: "Mechanical keyboard visualization focused on keycap translucency, soft light and a decorative product mood."
        },
        tags: ["Product", "Keyboard", "Materials"],
        gallery: ["images/projects/varmilo_keyboard.jpg"]
    },
    {
        id: "japanese-midnight",
        title: "Japanese Midnight",
        year: "2023",
        category: "environment",
        cover: "images/projects/japanese_midnight.png",
        ratio: "wide",
        role: { uk: "Environment design", en: "Environment design" },
        focus: { uk: "Mood, composition", en: "Mood, composition" },
        description: {
            uk: "Нічне середовище з cyberpunk-настроєм, контрастом теплого й холодного світла та чіткою композицією в глибині.",
            en: "Night environment with a cyberpunk mood, warm/cool light contrast and a clear depth composition."
        },
        tags: ["Environment", "Mood", "Night"],
        gallery: ["images/projects/japanese_midnight.png"]
    },
    {
        id: "tik-tik-1",
        title: "Tik Tik 1",
        year: "2023",
        category: "character",
        cover: "images/projects/tik_tik_1.png",
        ratio: "tall",
        role: { uk: "Character concept", en: "Character concept" },
        focus: { uk: "Shape, stylization", en: "Shape, stylization" },
        description: {
            uk: "Вертикальний character frame з простим силуетом, гумором і стилізованою подачею.",
            en: "Vertical character frame with a simple silhouette, humor and stylized presentation."
        },
        tags: ["Character", "Concept", "Stylized"],
        gallery: ["images/projects/tik_tik_1.png"]
    },
    {
        id: "olive-oil",
        title: "Olive Oil Design",
        year: "2024",
        category: "product",
        cover: "images/projects/olive_oil_bottle.png",
        ratio: "wide",
        role: { uk: "Product shot", en: "Product shot" },
        focus: { uk: "Glass, label, light", en: "Glass, label, light" },
        description: {
            uk: "Чистий предметний рендер пляшки з преміальним світлом, прозорістю скла та акуратною композицією.",
            en: "Clean product render of a bottle with premium lighting, glass transparency and restrained composition."
        },
        tags: ["Product", "Bottle", "Glass"],
        gallery: ["images/projects/olive_oil_bottle.png"]
    },
    {
        id: "geometric-2023",
        title: "Geometric 2023",
        year: "2023",
        category: "abstract",
        cover: "images/projects/project_2023.png",
        ratio: "tall",
        role: { uk: "Graphic experiment", en: "Graphic experiment" },
        focus: { uk: "Primitives, balance", en: "Primitives, balance" },
        description: {
            uk: "Абстрактна композиція з базових форм, де головними є ритм, простота та баланс мас.",
            en: "Abstract composition built from basic forms, focused on rhythm, simplicity and mass balance."
        },
        tags: ["Abstract", "Graphic", "Forms"],
        gallery: ["images/projects/project_2023.png"]
    },
    {
        id: "store-archvis",
        title: "Store Arch-Vis",
        year: "2024",
        category: "archviz",
        cover: "images/projects/store_archvis.png",
        ratio: "wide",
        role: { uk: "Interior visualization", en: "Interior visualization" },
        focus: { uk: "Space, scale, retail", en: "Space, scale, retail" },
        description: {
            uk: "Візуалізація retail-простору з акцентом на чисту геометрію, масштаб і читабельність інтер'єру.",
            en: "Retail interior visualization focused on clean geometry, scale and readable spatial layout."
        },
        tags: ["Archviz", "Interior", "Retail"],
        gallery: ["images/projects/store_archvis.png"]
    },
    {
        id: "cherry-perfume",
        title: "Cherry Perfume",
        year: "2024",
        category: "product",
        cover: "images/projects/cherry_perfume.png",
        ratio: "tall",
        role: { uk: "Cinematic product", en: "Cinematic product" },
        focus: { uk: "Bottle, contrast", en: "Bottle, contrast" },
        description: {
            uk: "Вертикальний beauty shot для парфуму з високим контрастом, сильним силуетом і насиченим матеріалом.",
            en: "Vertical beauty shot for perfume with high contrast, a strong silhouette and rich material presence."
        },
        tags: ["Product", "Perfume", "Cinematic"],
        gallery: ["images/projects/cherry_perfume.png"]
    },
    {
        id: "shure-sm7b",
        title: "Shure SM7B",
        year: "2024",
        category: "product",
        cover: "images/projects/shure_sm7b.png",
        ratio: "wide",
        role: { uk: "Hardware render", en: "Hardware render" },
        focus: { uk: "Hard surface, texture", en: "Hard surface, texture" },
        description: {
            uk: "Рендер мікрофона з увагою до hard surface форми, сітки, фактури та студійного світла.",
            en: "Microphone render with attention to hard surface form, grille detail, texture and studio lighting."
        },
        tags: ["Product", "Hardware", "Texture"],
        gallery: ["images/projects/shure_sm7b.png"]
    },
    {
        id: "x10-lamp",
        title: "X10 Lamp",
        year: "2022",
        category: "product",
        cover: "images/projects/x10_lamp.png",
        ratio: "wide",
        role: { uk: "Product design", en: "Product design" },
        focus: { uk: "Form, interior light", en: "Form, interior light" },
        description: {
            uk: "Концепт настільної лампи з простим силуетом, м'якою подачею та інтер'єрним настроєм.",
            en: "Desk lamp concept with a simple silhouette, soft presentation and an interior-focused mood."
        },
        tags: ["Product", "Lamp", "Interior"],
        gallery: ["images/projects/x10_lamp.png"]
    },
    {
        id: "hator-signify",
        title: "HATOR Signify",
        year: "2024",
        category: "simulation",
        cover: "images/projects/hator_signify.gif",
        ratio: "square",
        role: { uk: "Promotional motion", en: "Promotional motion" },
        focus: { uk: "RGB, product energy", en: "RGB, product energy" },
        description: {
            uk: "Промо-візуал для gaming hardware з RGB-акцентом, світловою енергією і loop-friendly подачею.",
            en: "Promotional visual for gaming hardware with an RGB accent, light energy and loop-friendly presentation."
        },
        tags: ["Motion", "Product", "RGB"],
        gallery: ["images/projects/hator_signify.gif"]
    },
    {
        id: "houdini-sim",
        title: "Houdini Sim",
        year: "2021",
        category: "simulation",
        cover: "images/projects/houdini_simulation.png",
        ratio: "wide",
        role: { uk: "Simulation study", en: "Simulation study" },
        focus: { uk: "Particles, motion", en: "Particles, motion" },
        description: {
            uk: "Експеримент з Houdini-симуляцією, де важливі рух, щільність частинок і графічний ритм.",
            en: "Houdini simulation experiment focused on movement, particle density and graphic rhythm."
        },
        tags: ["Houdini", "Simulation", "Motion"],
        gallery: ["images/projects/houdini_simulation.png"]
    }
];

const state = {
    lang: "uk",
    filter: "all",
    view: "grid",
    featuredIndex: 0,
    modalIndex: null,
    modalImageIndex: 0
};

const els = {
    langBtn: document.getElementById("lang-btn"),
    heroImage: document.getElementById("hero-image"),
    featuredStrip: document.getElementById("featured-strip"),
    featuredMeta: document.getElementById("featured-meta"),
    featuredTitle: document.getElementById("featured-title"),
    featuredDesc: document.getElementById("featured-desc"),
    featuredRole: document.getElementById("featured-role"),
    featuredFocus: document.getElementById("featured-focus"),
    filterTabs: document.getElementById("filter-tabs"),
    projectCount: document.getElementById("project-count"),
    projectGrid: document.getElementById("project-grid"),
    gridViewBtn: document.getElementById("grid-view-btn"),
    listViewBtn: document.getElementById("list-view-btn"),
    modal: document.getElementById("project-modal"),
    modalClose: document.getElementById("modal-close"),
    modalPrev: document.getElementById("modal-prev"),
    modalNext: document.getElementById("modal-next"),
    modalImage: document.getElementById("modal-image"),
    modalMeta: document.getElementById("modal-meta"),
    modalTitle: document.getElementById("modal-title"),
    modalDescription: document.getElementById("modal-description"),
    modalTags: document.getElementById("modal-tags"),
    modalThumbs: document.getElementById("modal-thumbs")
};

function text(key) {
    return copy[state.lang][key] || copy.uk[key] || key;
}

function localized(value) {
    if (typeof value === "string") return value;
    return value[state.lang] || value.uk || value.en || "";
}

function categoryName(project) {
    const label = categoryLabels[project.category];
    return label ? localized(label) : project.category;
}

function escapeHtml(value) {
    return String(value)
        .replaceAll("&", "&amp;")
        .replaceAll("<", "&lt;")
        .replaceAll(">", "&gt;")
        .replaceAll('"', "&quot;")
        .replaceAll("'", "&#039;");
}

function visibleIndices() {
    return projects
        .map((project, index) => ({ project, index }))
        .filter(({ project }) => state.filter === "all" || project.category === state.filter)
        .map(({ index }) => index);
}

function updateStaticCopy() {
    document.documentElement.lang = state.lang;

    document.querySelectorAll("[data-i18n]").forEach((node) => {
        const key = node.getAttribute("data-i18n");
        node.textContent = text(key);
    });

    els.langBtn.textContent = state.lang === "uk" ? "EN" : "UA";
    els.langBtn.setAttribute("aria-label", state.lang === "uk" ? "Switch to English" : "Перемкнути українською");
    els.gridViewBtn.setAttribute("aria-label", text("gridView"));
    els.gridViewBtn.setAttribute("title", text("gridView"));
    els.listViewBtn.setAttribute("aria-label", text("listView"));
    els.listViewBtn.setAttribute("title", text("listView"));
}

function renderFilters() {
    els.filterTabs.innerHTML = filters.map((filter) => `
        <button class="filter-btn${filter.id === state.filter ? " is-active" : ""}" type="button"
            data-filter="${filter.id}" aria-pressed="${filter.id === state.filter}">
            ${escapeHtml(localized(filter.label))}
        </button>
    `).join("");

    els.filterTabs.querySelectorAll("[data-filter]").forEach((button) => {
        button.addEventListener("click", () => {
            state.filter = button.dataset.filter;
            const nextVisible = visibleIndices();
            if (nextVisible.length && !nextVisible.includes(state.featuredIndex)) {
                setFeatured(nextVisible[0]);
            }
            renderAll();
        });
    });
}

function renderFeaturedStrip() {
    els.featuredStrip.innerHTML = projects.map((project, index) => `
        <button class="strip-item${index === state.featuredIndex ? " is-active" : ""}" type="button"
            data-featured-index="${index}" aria-label="${escapeHtml(text("openProject"))}: ${escapeHtml(project.title)}">
            <img src="${project.cover}" alt="" loading="lazy">
            <span>${escapeHtml(project.title)}</span>
        </button>
    `).join("");

    els.featuredStrip.querySelectorAll("[data-featured-index]").forEach((button) => {
        button.addEventListener("click", () => setFeatured(Number(button.dataset.featuredIndex)));
    });
}

function setFeatured(index) {
    const project = projects[index];
    if (!project) return;

    state.featuredIndex = index;
    els.heroImage.style.opacity = "0";

    window.setTimeout(() => {
        els.heroImage.src = project.cover;
        els.heroImage.alt = `${project.title} render`;
        els.heroImage.style.opacity = "0.82";
    }, 120);

    els.featuredMeta.textContent = `${categoryName(project)} / ${project.year}`;
    els.featuredTitle.textContent = project.title;
    els.featuredDesc.textContent = localized(project.description);
    els.featuredRole.textContent = localized(project.role);
    els.featuredFocus.textContent = localized(project.focus);
    renderFeaturedStrip();
}

function projectCard(project, index) {
    const tagMarkup = project.tags.slice(0, 3).map((tag) => `<span>${escapeHtml(tag)}</span>`).join("");

    return `
        <article class="project-card ratio-${project.ratio}">
            <button class="project-hit" type="button" data-project-index="${index}"
                aria-label="${escapeHtml(text("openProject"))}: ${escapeHtml(project.title)}">
                <div class="project-image">
                    <img src="${project.cover}" alt="${escapeHtml(project.title)} render" loading="lazy">
                </div>
                <div class="project-body">
                    <span class="project-kicker">${escapeHtml(categoryName(project))} / ${project.year}</span>
                    <div class="project-title-row">
                        <h3>${escapeHtml(project.title)}</h3>
                        <svg aria-hidden="true" viewBox="0 0 24 24">
                            <path d="M7 17 17 7M9 7h8v8" />
                        </svg>
                    </div>
                    <p>${escapeHtml(localized(project.description))}</p>
                    <div class="project-tags">${tagMarkup}</div>
                </div>
            </button>
        </article>
    `;
}

function renderProjects() {
    const indices = visibleIndices();
    els.projectGrid.classList.toggle("is-list", state.view === "list");
    els.projectCount.textContent = `${indices.length} ${text("projectCount")}`;
    els.projectGrid.innerHTML = indices.map((index) => projectCard(projects[index], index)).join("");

    els.projectGrid.querySelectorAll("[data-project-index]").forEach((button) => {
        button.addEventListener("click", () => openModal(Number(button.dataset.projectIndex)));
    });
}

function setView(view) {
    state.view = view;
    els.gridViewBtn.classList.toggle("is-active", view === "grid");
    els.listViewBtn.classList.toggle("is-active", view === "list");
    renderProjects();
}

function openModal(index) {
    if (!projects[index]) return;

    state.modalIndex = index;
    state.modalImageIndex = 0;
    renderModal();
    els.modal.classList.add("is-open");
    els.modal.setAttribute("aria-hidden", "false");
    document.body.classList.add("modal-open");
    els.modalClose.focus();
}

function closeModal() {
    els.modal.classList.remove("is-open");
    els.modal.setAttribute("aria-hidden", "true");
    document.body.classList.remove("modal-open");
    state.modalIndex = null;
}

function renderModal() {
    const project = projects[state.modalIndex];
    if (!project) return;

    const gallery = project.gallery.length ? project.gallery : [project.cover];
    const currentImage = gallery[state.modalImageIndex] || gallery[0];

    els.modalImage.src = currentImage;
    els.modalImage.alt = `${project.title} render`;
    els.modalMeta.textContent = `${categoryName(project)} / ${project.year}`;
    els.modalTitle.textContent = project.title;
    els.modalDescription.textContent = localized(project.description);
    els.modalTags.innerHTML = project.tags.map((tag) => `<span>${escapeHtml(tag)}</span>`).join("");

    els.modalThumbs.innerHTML = gallery.length > 1
        ? gallery.map((image, index) => `
            <button class="thumb-btn${index === state.modalImageIndex ? " is-active" : ""}" type="button"
                data-thumb-index="${index}" aria-label="${escapeHtml(project.title)} image ${index + 1}">
                <img src="${image}" alt="" loading="lazy">
            </button>
        `).join("")
        : "";

    els.modalThumbs.querySelectorAll("[data-thumb-index]").forEach((button) => {
        button.addEventListener("click", () => {
            state.modalImageIndex = Number(button.dataset.thumbIndex);
            renderModal();
        });
    });
}

function stepModal(direction) {
    if (state.modalIndex === null) return;

    const indices = visibleIndices();
    const list = indices.length ? indices : projects.map((_, index) => index);
    const position = list.indexOf(state.modalIndex);
    const nextPosition = position === -1
        ? 0
        : (position + direction + list.length) % list.length;

    state.modalIndex = list[nextPosition];
    state.modalImageIndex = 0;
    renderModal();
}

function renderAll() {
    updateStaticCopy();
    renderFilters();
    renderFeaturedStrip();
    renderProjects();

    if (state.modalIndex !== null) {
        renderModal();
    }
}

els.langBtn.addEventListener("click", () => {
    state.lang = state.lang === "uk" ? "en" : "uk";
    renderAll();
    setFeatured(state.featuredIndex);
});

els.gridViewBtn.addEventListener("click", () => setView("grid"));
els.listViewBtn.addEventListener("click", () => setView("list"));
els.modalClose.addEventListener("click", closeModal);
els.modalPrev.addEventListener("click", () => stepModal(-1));
els.modalNext.addEventListener("click", () => stepModal(1));

els.modal.addEventListener("click", (event) => {
    if (event.target === els.modal) {
        closeModal();
    }
});

document.addEventListener("keydown", (event) => {
    if (state.modalIndex === null) return;

    if (event.key === "Escape") closeModal();
    if (event.key === "ArrowRight") stepModal(1);
    if (event.key === "ArrowLeft") stepModal(-1);
});

renderAll();
setFeatured(0);
